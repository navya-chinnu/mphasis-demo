package Runner;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(publish = true,
    features = {"C:\\Users\\NAVYA\\Downloads\\RLL_DemoWeb_Shop\\RLL_DemoWeb_Shop\\src\\test\\java\\Features\\SearchFeature.feature"},
    glue = {"Steps"},
    dryRun = false,
    tags = "@SearchTest",
    plugin = {
        "pretty",
        "html:target/cucumberreport_search.html",
        "json:target/cucumber.json",
        "junit:target/xmlReport.xml",
        "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
        "timeline:test-output-thread/"
    },
    monochrome = true
)


public class junitSearch {

}
